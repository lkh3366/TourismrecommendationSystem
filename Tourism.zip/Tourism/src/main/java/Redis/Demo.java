package Redis;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Flow.Publisher;

import Utils.RedisUtil;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

public class Demo {
	public static void main(String[] args)
	{
		Jedis jedis=RedisUtil.getInstance().getJedis();
		System.out.print(jedis.ping());
	        // ��ȡ�洢�����ݲ����
	       
//	        jedis.rpush("goods:comments:soft:1", "{'id':'3','content':'laji','date':'2019-10-17'}");
//	        jedis.rpush("goods:comments:soft:1", "{'id':'4','content':'lajia','date':'2019-10-18'}");
	        List<String> list = jedis.lrange("goods:comments:soft:1", 0,3);
	        for(int i=0; i<list.size(); i++) {
	            System.out.println("�б���Ϊ: "+list.get(i));
	        }
//		List<user> users=new ArrayList<user>();
//		List<String> names=new ArrayList<String>();
//		names.add("����");
//		names.add("zhangsi");
//		List<String> sex=new ArrayList<String>();
//		sex.add("��");
//		sex.add("female");
//		users.add(new user(names,sex,10));
//		
//		List<String> names2=new ArrayList<String>();
//		names.add("����2");
//		names.add("zhangsi2");
//		List<String> sex2=new ArrayList<String>();
//		sex.add("��2");
//		sex.add("female2");
//		users.add(new user(names2,sex2,20));
//		Map map=new HashMap<String, String>();
//		map.put("id", "1");
//		map.put("name", "��Ȫ��");
//		map.put("password", "123456");
//		jedis.hmset("user:1", map);
		jedis.close();
	}
}
