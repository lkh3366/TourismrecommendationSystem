package Redis;

import java.util.List;

public class user {
	List<String> name;
	List<String> sex;
	int length;
	public user() {}
	@Override
	public String toString() {
		return "user [name=" + name + ", sex=" + sex + ", length=" + length + "]";
	}
	public user(List<String> name, List<String> sex, int length) {
		super();
		this.name = name;
		this.sex = sex;
		this.length = length;
	}
	public List<String> getName() {
		return name;
	}
	public void setName(List<String> name) {
		this.name = name;
	}
	public List<String> getSex() {
		return sex;
	}
	public void setSex(List<String> sex) {
		this.sex = sex;
	}
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
}
