 function init()//初始化参量
{
	let loginer=localStorage.getItem("loginer");
	let json=JSON.parse(loginer);
	let username=json.username;
	let data={sid:username};
	ajax("/stepitemrecord/isstutest",data, function(d) { 
		var msg=d.msg;
		msgbox(msg);
	},"get"); 
	var sessionStorage = window.sessionStorage;
	if(!sessionStorage){
		    console.log("该浏览器不支持本地缓存");
			sessionStorage={};
		}	
		sessionStorage.setItem("ChooseEorH","false");//false：未选择 E:选择了E,H:选择了H
		sessionStorage.setItem("IsEmissionWireInstalled","0");//安装了发射天线
		sessionStorage.setItem("IsEmissionCableConnected","0");//连接了发射天线电缆
		sessionStorage.setItem("IsTestedWireInstalled","0");//安装接收天线 
		sessionStorage.setItem("TestedWireInstalledName","0");//接受天线名字
		sessionStorage.setItem("IsTestedCableConnected","0");//连接了接收天线电缆
		sessionStorage.setItem("IsTurnTableCtrlCableConnected","0");//连接转台控制电缆
		sessionStorage.setItem("IsTurnTablePowerConnected","0");//连接转台电源
		sessionStorage.setItem("IsAdjustHight","false");//调整天线高度
		sessionStorage.setItem("IsDarkDoorOpen","true");//开或关暗室门 初始化开启状态
		sessionStorage.setItem("IsSignalGPIBConnected","0");//连接信号源GPIB线 初始化未连接
		sessionStorage.setItem("IsSignalRFConnected","0");//连接信号源射频电缆线 初始化未连接
		sessionStorage.setItem("IsSpectrumGPIBConnected","0");//连接频谱仪GPIB线 初始化未连接
		sessionStorage.setItem("IsSpectrumRFConnected","0");//连接频谱仪射频电缆线 初始化未连接
		sessionStorage.setItem("MainPower","0");//总电源开关 初始化关闭状态
		sessionStorage.setItem("SignalPower","0");//信号源开关 初始化关闭状态
		sessionStorage.setItem("SpectrumPower","0");//频谱仪开关 初始化关闭状态
		sessionStorage.setItem("ComputerPower","0");//电脑开关 初始化关闭状态
		sessionStorage.setItem("MeasuringApp","false");//测试软件 初始化为未打开
		sessionStorage.setItem("SetUpFrequency","false");//设置频率 初始为0表示未设置频率
		sessionStorage.setItem("SetUpWidth","false");//设置幅度 初始为0表示未设置 为1表示设置
		sessionStorage.setItem("StartMeasure","false");//开始测量
		sessionStorage.setItem("StopMeasure","false");//停止测量
		sessionStorage.setItem("SequenceErrorCo","false");//关闭电源操作是否出现错误，电脑为打开状态 初始为0表示未错误
		sessionStorage.setItem("SequenceErrorSp","false");//关闭电源操作是否出现错误，频谱仪为打开状态 初始为0表示未错误
		sessionStorage.setItem("SequenceErrorSi","false");//关闭电源操作是否出现错误，信号源为打开状态 初始为0表示未错误
		sessionStorage.setItem("PowerErrorSi","false");//出现错误操作扣分
		sessionStorage.setItem("PowerErrorSp","false");//出现错误操作扣分
		sessionStorage.setItem("CalculatReceivedPower","false");//是否计算了接受频率
		sessionStorage.setItem("Frequency","0");//MHz
		sessionStorage.setItem("Width","0");//dBm
		sessionStorage.setItem("Degrees","0");//初始为零度
		sessionStorage.setItem("FinishE","false");//是否完成E面实验 初始化
		sessionStorage.setItem("FinishH","false");//是否完成H面实验 初始化
		sessionStorage.setItem("Pointx","0");
		sessionStorage.setItem("Pointy","0");
		sessionStorage.setItem("ZzWireFrequency","0");//初始化自制天线频率
		
		// 得分对应步骤条目
		sessionStorage.setItem("1","0");
		sessionStorage.setItem("2","0");
		sessionStorage.setItem("3","0");
		sessionStorage.setItem("4","0");
		sessionStorage.setItem("5","0");
		sessionStorage.setItem("6","0");
		sessionStorage.setItem("7","0");
		sessionStorage.setItem("8","0");
		sessionStorage.setItem("9","0");
		sessionStorage.setItem("10","0");
		sessionStorage.setItem("11","0");
		sessionStorage.setItem("12","0");
		sessionStorage.setItem("13","0");
		sessionStorage.setItem("14","0");
		sessionStorage.setItem("15","0");
		sessionStorage.setItem("16","0");
		sessionStorage.setItem("17","0");
		sessionStorage.setItem("18","0");
		sessionStorage.setItem("19","0");
		sessionStorage.setItem("20","0");
		sessionStorage.setItem("21","0");
		sessionStorage.setItem("22","0");
		sessionStorage.setItem("23","0");
		sessionStorage.setItem("24","0");
		sessionStorage.setItem("25","0");
		sessionStorage.setItem("26","0");
		sessionStorage.setItem("27","0");
		sessionStorage.setItem("28","0");
		sessionStorage.setItem("29","0");
		sessionStorage.setItem("30","0");
		sessionStorage.setItem("31","0");
		sessionStorage.setItem("32","0");
		sessionStorage.setItem("33","0");
		sessionStorage.setItem("34","0");
		sessionStorage.setItem("35","0");
		sessionStorage.setItem("36","0");
		sessionStorage.setItem("37","0");
		sessionStorage.setItem("38","0");
//		sessionStorage.setItem("39","0");
}
function ChooseEorH(arg)
{
	var sessionStorage = window.sessionStorage;
	if(!sessionStorage){
		    console.log("该浏览器不支持本地缓存");
			sessionStorage={};
		}
	if(arg.toString()=="E")//选择了E面水平实验
	{
		sessionStorage.setItem("ChooseEorH","E");
	}
	if(arg.toString()=="H")//选择了H面水平实验
	{
		sessionStorage.setItem("ChooseEorH","H");
	}
}
function IsEmissionWireInstalled(arg)
{
	var sessionStorage = window.sessionStorage;
	if(!sessionStorage){
		    console.log("该浏览器不支持本地缓存");
			sessionStorage={};
		}
	if(arg.toString()=="false")//初始化为0代表未进行操作
	 {
		sessionStorage.setItem("IsEmissionWireInstalled","false"); //拆除发射天线功能
	}
	if(arg.toString()=="E")//安装了E面水平发射天线
	{
		sessionStorage.setItem("IsEmissionWireInstalled","E");
	}			
	if(arg.toString()=="H")//安装了H面水平发射天线
	{
		sessionStorage.setItem("IsEmissionWireInstalled","H");	
	}	
}
function IsEmissionCableConnected(arg)
{
var sessionStorage = window.sessionStorage;
	if(!sessionStorage){
		    console.log("该浏览器不支持本地缓存");
			sessionStorage={};
		}
	if(arg.toString()=="false")//初始化为断开为false，拆开状态
	{
		// alert("拆开");
		sessionStorage.setItem("IsEmissionCableConnected","false"); //拆除发射天线功能
		gameInstance.SendMessage("Manager","SendToUnity","NoWaveform");
		sessionStorage.setItem("CalculatReceivedPower","false")//停止了计算接收功率
		gameInstance.SendMessage("Manager","SendToUnity","ShowNoiseLevel");
		gameInstance.SendMessage("Manager","SendToUnity","stopAUTOTUNE");
		gameInstance.SendMessage("Manager","SendToUnity","WireSupportStopRotate");
	}
	if(arg.toString()=="true")//连接发射天线电缆
	{
		// alert("连接发射天线电缆");
		if(sessionStorage.getItem("IsEmissionWireInstalled")=="E"&&sessionStorage.getItem("MainPower")=="true"&&sessionStorage.getItem("IsSignalGPIBConnected")=="true"&&sessionStorage.getItem("IsSignalRFConnected")=="true")
		{
			var hznum=parseFloat(String(sessionStorage.getItem("Frequency"))).toFixed(2);
			if(hznum>=800.0&&hznum<=18000.0)
				gameInstance.SendMessage("Manager","SendToUnity","OpenWaveformE");
				// alert("暗室显示波形E");
		}
		if(sessionStorage.getItem("IsEmissionWireInstalled")=="H"&&sessionStorage.getItem("MainPower")=="true"&&sessionStorage.getItem("IsSignalGPIBConnected")=="true"&&sessionStorage.getItem("IsSignalRFConnected")=="true")
		{
			var hznum=parseFloat(String(sessionStorage.getItem("Frequency"))).toFixed(2);
			if(hznum>=800.0&&hznum<=18000.0)
				gameInstance.SendMessage("Manager","SendToUnity","OpenWaveformH");
				// alert("暗室显示波形H");
		}
		sessionStorage.setItem("IsEmissionCableConnected","true");	
	}
}
function IsTestedWireInstalled(arg)
{
	var sessionStorage = window.sessionStorage;
	if(!sessionStorage){
		    console.log("该浏览器不支持本地缓存");
			sessionStorage={};
		}
	if(arg.toString()=="false")//初始化为0代表未进行操作
	{
		// alert(arg);
		sessionStorage.setItem("IsTestedWireInstalled","false"); //拆除接受天线功能
	}
	if(arg.toString()=="E")//安装了E面水平接受天线
	{
		// alert(arg);
		sessionStorage.setItem("IsTestedWireInstalled","E");	
	}
	if(arg.toString()=="H")//安装了H面水平接受天线
	{
		// alert(arg);
		sessionStorage.setItem("IsTestedWireInstalled","H");
	}	
}
function TestedWireInstalledName(arg)
{
	var sessionStorage = window.sessionStorage;
	if(!sessionStorage){
		    console.log("该浏览器不支持本地缓存");
			sessionStorage={};
		}
//	alert(arg.toString());
	if(arg.toString()=="Yagiantenna")
		sessionStorage.setItem("TestedWireInstalledName","Yagiantenna");//八木天线
	if(arg.toString()=="Hornantenna1")
		sessionStorage.setItem("TestedWireInstalledName","Hornantenna");//喇叭天线
	if(arg.toString()=="Hornantenna2")
		sessionStorage.setItem("TestedWireInstalledName","Hornantenna");//喇叭天线
	if(arg.toString()=="Parabolicantenna")
		sessionStorage.setItem("TestedWireInstalledName","Parabolicantenna");//抛物面天线
	if(arg.toString()=="Whipantenna")
		sessionStorage.setItem("TestedWireInstalledName","Whipantenna");//鞭状天线
	if(arg.toString()=="HomemadeYagiantenna")
		sessionStorage.setItem("TestedWireInstalledName","HomemadeYagiantenna");//自制八木天线
	if(arg.toString()=="Monopoleantenna")
		sessionStorage.setItem("TestedWireInstalledName","Monopoleantenna");//单极子天线
}
function IsTestedCableConnected(arg)
{
	var sessionStorage = window.sessionStorage;
	if(!sessionStorage){
		    console.log("该浏览器不支持本地缓存");
			sessionStorage={};
		}
	if(arg.toString()=="false")//拔掉接收天线电缆 初始化值 
	{
		// alert(arg);
		sessionStorage.setItem("IsTestedCableConnected","false");
		sessionStorage.setItem("CalculatReceivedPower","false")//停止了计算接收功率
		gameInstance.SendMessage("Manager","SendToUnity","WireSupportStopRotate");
		gameInstance.SendMessage("Manager","SendToUnity","stopAUTOTUNE");
		gameInstance.SendMessage("Manager","SendToUnity","ShowNoiseLevel");
	}
	if(arg.toString()=="true")//插上了接收天线电缆
	{
		// alert(arg);
		sessionStorage.setItem("IsTestedCableConnected","true");
	}
}
function IsTurnTableCtrlCableConnected(arg)
{
	var sessionStorage = window.sessionStorage;
	if(!sessionStorage){
		    console.log("该浏览器不支持本地缓存");
			sessionStorage={};
		}
	if(arg.toString()=="false")//拔掉转台控制电缆 初始化值
	{
		// alert(arg);
		sessionStorage.setItem("IsTurnTableCtrlCableConnected","false");
		sessionStorage.setItem("CalculatReceivedPower","false")//停止了计算接收功率
		gameInstance.SendMessage("Manager","SendToUnity","WireSupportStopRotate");
		gameInstance.SendMessage("Manager","SendToUnity","stopAUTOTUNE");
		gameInstance.SendMessage("Manager","SendToUnity","ShowNoiseLevel");
	}
	if(arg.toString()=="true")//插上了转台控制电缆
	{
		// alert(arg);
		sessionStorage.setItem("IsTurnTableCtrlCableConnected","true");
	}
}
function IsTurnTablePowerConnected(arg)
{
	var sessionStorage = window.sessionStorage;
	if(!sessionStorage){
		    console.log("该浏览器不支持本地缓存");
			sessionStorage={};
		}
	if(arg.toString()=="false")//拔掉转台电源 初始化值
	{
		// alert(arg);
		sessionStorage.setItem("IsTurnTablePowerConnected","false");
		sessionStorage.setItem("CalculatReceivedPower","false")//停止了计算接收功率
		gameInstance.SendMessage("Manager","SendToUnity","WireSupportStopRotate");
		gameInstance.SendMessage("Manager","SendToUnity","stopAUTOTUNE");
		gameInstance.SendMessage("Manager","SendToUnity","ShowNoiseLevel");
		
	}
	if(arg.toString()=="true")//插上了转台电源
	{
		// alert(arg);
		sessionStorage.setItem("IsTurnTablePowerConnected","true");
	}
}
function IsAdjustHight(arg)
{
	var sessionStorage = window.sessionStorage;
	if(!sessionStorage){
		    console.log("该浏览器不支持本地缓存");
			sessionStorage={};
		}
	if(arg.toString()=="false")//未调整天线高度 初始化值
	{
		// alert(arg);
		sessionStorage.setItem("IsAdjustHight","false");
	}
	if(arg.toString()=="true")//调整了天线高度
	{
		// alert(arg);
		sessionStorage.setItem("IsAdjustHight","true");
	}
}
function IsDarkDoorOpen(arg){ //开关暗室门
	//boolean控制初始为false未操作关闭状态 控制开关这里可以不传参数
	var sessionStorage = window.sessionStorage;
	if(!sessionStorage){
		    console.log("该浏览器不支持本地缓存");
			sessionStorage={};
		}
	var IsSignal=sessionStorage.getItem("IsDarkDoorOpen")
	if(IsSignal=="true")
	{
		sessionStorage.setItem("IsDarkDoorOpen","false");
		// alert("关门");
	}
	else{
		sessionStorage.setItem("IsDarkDoorOpen","true");
		// alert("开门");
	}
}
function IsSignalGPIBConnected(arg)
{
	var sessionStorage = window.sessionStorage;
	if(!sessionStorage){
		    console.log("该浏览器不支持本地缓存");
			sessionStorage={};
		}
	if(arg.toString()=="false")//拔掉信号源GPIB线 初始化值
	{
		// alert(arg);
		sessionStorage.setItem("IsSignalGPIBConnected","false");
		sessionStorage.setItem("CalculatReceivedPower","false")//停止了计算接收功率
		gameInstance.SendMessage("Manager","SendToUnity","WireSupportStopRotate");
		gameInstance.SendMessage("Manager","SendToUnity","stopAUTOTUNE");
		gameInstance.SendMessage("Manager","SendToUnity","ShowNoiseLevel");
		gameInstance.SendMessage("Manager","SendToUnity","NoWaveform");
	}
	if(arg.toString()=="true")//连接信号源GPIB线
	{
		// alert(arg);
		sessionStorage.setItem("IsSignalGPIBConnected","true");
	}
}
function IsSignalRFConnected(arg)
{
	var sessionStorage = window.sessionStorage;
	if(!sessionStorage){
		    console.log("该浏览器不支持本地缓存");
			sessionStorage={};
		}
	if(arg.toString()=="false")//拔掉信号源射频电缆线 初始化值
	{
		// alert(arg);
		sessionStorage.setItem("IsSignalRFConnected","false");
		sessionStorage.setItem("CalculatReceivedPower","false")//停止了计算接收功率
		gameInstance.SendMessage("Manager","SendToUnity","WireSupportStopRotate");
		gameInstance.SendMessage("Manager","SendToUnity","stopAUTOTUNE");
		gameInstance.SendMessage("Manager","SendToUnity","ShowNoiseLevel");
		gameInstance.SendMessage("Manager","SendToUnity","NoWaveform");
	}
	if(arg.toString()=="true")//连接信号源射频电缆线
	{
		// alert(arg);
		sessionStorage.setItem("IsSignalRFConnected","true");
	}
}
function IsSpectrumGPIBConnected(arg)
{
	var sessionStorage = window.sessionStorage;
	if(!sessionStorage){
		    console.log("该浏览器不支持本地缓存");
			sessionStorage={};
		}
	if(arg.toString()=="false")//拔掉频谱仪GPIB线 初始化值
	{
		// alert(arg);
		sessionStorage.setItem("IsSpectrumGPIBConnected","false");
		sessionStorage.setItem("CalculatReceivedPower","false")//停止了计算接收功率
		gameInstance.SendMessage("Manager","SendToUnity","WireSupportStopRotate");
		gameInstance.SendMessage("Manager","SendToUnity","ShowNoiseLevel");
		gameInstance.SendMessage("Manager","SendToUnity","stopAUTOTUNE");
	}	
	if(arg.toString()=="true")//连接频谱仪GPIB线
	{
		// alert(arg);
		sessionStorage.setItem("IsSpectrumGPIBConnected","true");
		var hznum=parseFloat(String(sessionStorage.getItem("Frequency"))).toFixed(2);
		if(sessionStorage.getItem("IsSpectrumRFConnected")=="true"&&(hznum>=800.0&&hznum<=18000.0)&&sessionStorage.getItem("CalculatReceivedPower")=="true"&&sessionStorage.getItem("SpectrumPower")=="true")
		{
			gameInstance.SendMessage("Manager","SendToUnity","startAUTOTUNE");
			gameInstance.SendMessage("Manager","SendToUnity","StopNoiseLevel");
		}
		else{
				gameInstance.SendMessage("Manager","SendToUnity","ShowNoiseLevel");
		}
	}
}
function IsSpectrumRFConnected(arg)
{
	var sessionStorage = window.sessionStorage;
	if(!sessionStorage){
		    console.log("该浏览器不支持本地缓存");
			sessionStorage={};
		}
	if(arg.toString()=="false")//拔掉频谱仪射频电缆线 初始化值
	{
		// alert(arg);
		sessionStorage.setItem("IsSpectrumRFConnected","false");
		sessionStorage.setItem("CalculatReceivedPower","false")//停止了计算接收功率
		gameInstance.SendMessage("Manager","SendToUnity","WireSupportStopRotate");
		gameInstance.SendMessage("Manager","SendToUnity","ShowNoiseLevel");
		gameInstance.SendMessage("Manager","SendToUnity","stopAUTOTUNE");
	}
	if(arg.toString()=="true")//连接频谱仪射频电缆线
	{
		// alert(arg);
		sessionStorage.setItem("IsSpectrumRFConnected","true");
		var hznum=parseFloat(String(sessionStorage.getItem("Frequency"))).toFixed(2);
		if(sessionStorage.getItem("IsSpectrumGPIBConnected")=="true"&&sessionStorage.getItem("IsSpectrumRFConnected")=="true"&&(hznum>=800.0&&hznum<=18000.0)&&sessionStorage.getItem("CalculatReceivedPower")=="true"&&sessionStorage.getItem("SpectrumPower")=="true")
		{
			gameInstance.SendMessage("Manager","SendToUnity","startAUTOTUNE");
			gameInstance.SendMessage("Manager","SendToUnity","StopNoiseLevel");
		}
		else{
				gameInstance.SendMessage("Manager","SendToUnity","ShowNoiseLevel");
		}
	}	
}//-----------------------------------------------此处为连线拔线操作分界线--------------------------------------------------------
function MainPower(arg)//开或关总电源开关
{
	var sessionStorage = window.sessionStorage;
	if(!sessionStorage){
		    console.log("该浏览器不支持本地缓存");
			sessionStorage={};
		}
	if(sessionStorage.getItem("MainPower")=="true")//电源为开启状态 进行关闭操作
	{
		sessionStorage.setItem("MainPower","false");//设置电源为关闭状态
		if(sessionStorage.getItem("ComputerPower")=="true"||sessionStorage.getItem("SpectrumPower")=="true"||sessionStorage.getItem("SignalPower")=="true")
		{//如果关闭电源时有其余设备正在开启
			if(sessionStorage.getItem("ComputerPower")=="true"){
				sessionStorage.setItem("ComputerPower","false");//设置电脑为关闭状态
				sessionStorage.setItem("MeasuringApp","false");//设置测试软件为关闭状态
				sessionStorage.setItem("SequenceErrorCo","true");//步骤出现错误
				sessionStorage.setItem("MeasuringApp","false");//设置测试软件关闭
				gameInstance.SendMessage("Manager","SendToUnity","WireSupportStopRotate");//停止天线转动
				gameInstance.SendMessage("Manager","SendToUnity","CloseComputerPower");//显示屏灭
				sessionStorage.setItem("CalculatReceivedPower","false")//停止了计算接收功率
				gameInstance.SendMessage("Manager","SendToUnity","ShowNoiseLevel");
				gameInstance.SendMessage("Manager","SendToUnity","stopAUTOTUNE");
			}
			if(sessionStorage.getItem("SpectrumPower")=="true"){
				sessionStorage.setItem("SpectrumPower","false");//设置频谱仪为关闭状态
				sessionStorage.setItem("SequenceErrorSp","true");//步骤出现错误
				gameInstance.SendMessage("Manager","SendToUnity","CloseSpectrumPower");
				gameInstance.SendMessage("Manager","SendToUnity","stopAUTOTUNE");
				sessionStorage.setItem("CalculatReceivedPower","false")//停止了计算接收功率
				gameInstance.SendMessage("Manager","SendToUnity","WireSupportStopRotate");
				gameInstance.SendMessage("Manager","SendToUnity","ShowNoiseLevel");
				// alert("关闭频谱仪");
			}
			if(sessionStorage.getItem("SignalPower")=="true"){
				sessionStorage.setItem("SignalPower","false");//设置信号源关闭状态
				sessionStorage.setItem("SequenceErrorSi","true");//步骤出现错误
				sessionStorage.setItem("SignalPower","false");//str为false
				gameInstance.SendMessage("Manager","SendToUnity","WireSupportStopRotate");
				gameInstance.SendMessage("Manager","SendToUnity","NoWaveform");
				// alert("false");
				gameInstance.SendMessage("Manager","SendToUnity","CloseSignalPower"); //信号源屏幕灭
				sessionStorage.setItem("Frequency","0");//MHz
				sessionStorage.setItem("Width","0");//dBm
				sessionStorage.setItem("SetUpFrequency","false");
				sessionStorage.setItem("SetUpWidth","false");
				sessionStorage.setItem("CalculatReceivedPower","false")//停止了计算接收功率
				gameInstance.SendMessage("Manager","SendToUnity","ShowNoiseLevel");
				gameInstance.SendMessage("Manager","SendToUnity","stopAUTOTUNE");
			}
			sessionStorage.setItem("CalculatReceivedPower","false")//停止了计算接收功率
			gameInstance.SendMessage("Manager","SendToUnity","WireSupportStopRotate");
			gameInstance.SendMessage("Manager","SendToUnity","ShowNoiseLevel");
			gameInstance.SendMessage("Manager","SendToUnity","stopAUTOTUNE");
		}
		else
		{
			sessionStorage.setItem("SequenceErrorCo","false");//操作正确 仍为初始值
			sessionStorage.setItem("SequenceErrorSp","false");//操作正确 仍为初始值
			sessionStorage.setItem("SequenceErrorSi","false");//操作正确 仍为初始值
		}
		gameInstance.SendMessage("Manager","SendToUnity","NoWaveform");
		gameInstance.SendMessage("Manager","SendToUnity","NoWaveform2D");
		gameInstance.SendMessage("Manager","SendToUnity","WireSupportStopRotate");
		// alert("关闭暗室波形");
		// alert("false");
	}
	else//电源为关闭状态 进行开启操作
	{
		sessionStorage.setItem("MainPower","true");
	}
}
function SignalPower(arg)//信号源开关 初始为关闭
{
	var sessionStorage = window.sessionStorage;
	if(!sessionStorage){
		    console.log("该浏览器不支持本地缓存");
			sessionStorage={};
		}
	if(sessionStorage.getItem("SignalPower")=="true")//如果此时信号源为打开状态 进行关闭
	{
		sessionStorage.setItem("SignalPower","false");//str为false
		gameInstance.SendMessage("Manager","SendToUnity","WireSupportStopRotate");
		gameInstance.SendMessage("Manager","SendToUnity","NoWaveform");
		// alert("false");
		gameInstance.SendMessage("Manager","SendToUnity","CloseSignalPower"); //信号源屏幕灭
		sessionStorage.setItem("Frequency","0");//MHz
		sessionStorage.setItem("Width","0");//dBm
		sessionStorage.setItem("SetUpFrequency","false");
		sessionStorage.setItem("SetUpWidth","false");
		sessionStorage.setItem("CalculatReceivedPower","false")//停止了计算接收功率
		gameInstance.SendMessage("Manager","SendToUnity","ShowNoiseLevel");
		gameInstance.SendMessage("Manager","SendToUnity","stopAUTOTUNE");
		return;
	}
	if(sessionStorage.getItem("MainPower")=="true"&&(sessionStorage.getItem("SignalPower")=="false"||sessionStorage.getItem("SignalPower")=="0"))//如果电源打开，且此时信号源为关闭状态 进行打开否则无响应
	{
		if(sessionStorage.getItem("IsSignalGPIBConnected")=="false")//GBIB线未连接 扣分
			sessionStorage.setItem("PowerErrorSi","true");//出现错误操作扣分
		sessionStorage.setItem("SignalPower","true");
		// alert("true");
		gameInstance.SendMessage("Manager","SendToUnity","OpenSignalPower"); //信号源屏幕亮
		return;
	}	
}
function SpectrumPower(arg)//频谱仪开关 初始为关闭
{
	var sessionStorage = window.sessionStorage;
	if(!sessionStorage){
		    console.log("该浏览器不支持本地缓存");
			sessionStorage={};
		}
		if(sessionStorage.getItem("SpectrumPower")=="true")//如果此时频谱仪为打开状态 进行关闭
		{
			sessionStorage.setItem("SpectrumPower","false");
			// alert("false");
			gameInstance.SendMessage("Manager","SendToUnity","CloseSpectrumPower");
			gameInstance.SendMessage("Manager","SendToUnity","stopAUTOTUNE");
			sessionStorage.setItem("CalculatReceivedPower","false")//停止了计算接收功率
			gameInstance.SendMessage("Manager","SendToUnity","WireSupportStopRotate");
			gameInstance.SendMessage("Manager","SendToUnity","ShowNoiseLevel");
			return;
		}
		if(sessionStorage.getItem("MainPower")=="true"&&(sessionStorage.getItem("SpectrumPower")=="false"||sessionStorage.getItem("SpectrumPower")=="0"))//如果电源打开，且此时频谱仪为关闭状态 进行打开操作 否则无响应
		{
			if(sessionStorage.getItem("IsSpectrumGPIBConnected")=="false")//GBIB线未连接 扣分
				sessionStorage.setItem("PowerErrorSp","true");//出现错误操作扣分
			var hznum=parseFloat(String(sessionStorage.getItem("Frequency"))).toFixed(2);
			if(sessionStorage.getItem("IsSpectrumGPIBConnected")=="true"&&sessionStorage.getItem("IsSpectrumRFConnected")=="true"&&(hznum>=800.0&&hznum<=18000.0)&&sessionStorage.getItem("CalculatReceivedPower")=="true"){
				gameInstance.SendMessage("Manager","SendToUnity","startAUTOTUNE");
				gameInstance.SendMessage("Manager","SendToUnity","StopNoiseLevel");
			}
			else{
					gameInstance.SendMessage("Manager","SendToUnity","ShowNoiseLevel");
			}
			sessionStorage.setItem("SpectrumPower","true");
			// alert("true");
			gameInstance.SendMessage("Manager","SendToUnity","OpenSpectrumPower");
			return;
		}	
}
function ComputerPower(arg)//电脑开关 初始为关闭
{
	var sessionStorage = window.sessionStorage;
	if(!sessionStorage){
		    console.log("该浏览器不支持本地缓存");
			sessionStorage={};
		}
	if(sessionStorage.getItem("ComputerPower")=="true")//电脑为开启状态
	{
		sessionStorage.setItem("ComputerPower","false");//设置电脑为关闭状态
		sessionStorage.setItem("MeasuringApp","false");//设置测试软件关闭
		gameInstance.SendMessage("Manager","SendToUnity","WireSupportStopRotate");//停止天线转动
		gameInstance.SendMessage("Manager","SendToUnity","CloseComputerPower");//显示屏灭
		sessionStorage.setItem("CalculatReceivedPower","false")//停止了计算接收功率
		gameInstance.SendMessage("Manager","SendToUnity","ShowNoiseLevel");
		gameInstance.SendMessage("Manager","SendToUnity","stopAUTOTUNE");
		return;
	}
	if(sessionStorage.getItem("MainPower")=="true"&&(sessionStorage.getItem("ComputerPower")=="false"||sessionStorage.getItem("ComputerPower")=="0"))//如果电源打开，且此时电脑为关闭状态
	{
		sessionStorage.setItem("ComputerPower","true");//打开电脑
//		 alert("true");
		gameInstance.SendMessage("Manager","SendToUnity","OpenComputerPower");//显示屏亮
		return;
	}
}
//  ------------------------------------------------------------------------------------------------------------------MeasuringApp
function MeasuringApp(arg)//打开测试软件 默认为“false”关闭
{
	var sessionStorage = window.sessionStorage;
	if(!sessionStorage){
			console.log("该浏览器不支持本地缓存");
			sessionStorage={};
		}
	sessionStorage.setItem("MeasuringApp","true");//打开状态
	// alert(arg);
	gameInstance.SendMessage("Manager","SendToUnity","OpenMeasuringApp");//测试软件打开
}
// ---------------------------------------------------------------------------------------------------------------------
function SetUpFrequency(arg)//设置频率 有两种波形  //默认为0为错误频率 //为1为正确频率 范围为40k-100 GHZ
{
	var sessionStorage = window.sessionStorage;
	if(!sessionStorage){
		    console.log("该浏览器不支持本地缓存");
			sessionStorage={};
		}
		var str=arg.toString();	
		if(str.indexOf("GHz")!=-1||str.indexOf("MHz")!=-1||str.indexOf("KHz")!=-1)
		{
			if(str.indexOf("GHz")!=-1){
				str=str.replace("GHz","");
				str=str.trim();
				var a=parseFloat(1000*1000*parseFloat(str));
				// alert("转换为KHz:"+a.toString());
			}	
			if(str.indexOf("MHz")!=-1){
				str.replace("MHz","");
				str=str.trim();
				var a=parseFloat(1000*parseFloat(str));
				// alert("转换为KHz:"+a.toString());
			}	
			if(str.indexOf("KHz")!=-1){
				str.replace("KHz","");
				str=str.trim();
				var a=parseFloat(str);
				// alert("转换为KHz:"+a.toString());
			}
			if(a>=100.0&&a<=40000000.0)
			{
				gameInstance.SendMessage("Manager","SendToUnity","FreqMHzResult"+(a/1000).toFixed(2));
				sessionStorage.setItem("Frequency",String((a/1000).toFixed(2)));
				if(a>=800000&&a<=18000000)//频率范围800MHz-18GHz 进行计算并发送影响暗室波形变化的值
				{
					sessionStorage.setItem("SetUpFrequency","true");//频率设置正确 
					CalculatFrequency(String(a/1000));
				}
				else
					{
						gameInstance.SendMessage("Manager","SendToUnity","stopAUTOTUNE");
						gameInstance.SendMessage("Manager","SendToUnity","NoWaveform");
					}
			}else{
				if(a<100)
				{
					a=100.00;
					gameInstance.SendMessage("Manager","SendToUnity","FreqMHzResult"+(a/1000).toFixed(2));
					sessionStorage.setItem("Frequency",String((a/1000).toFixed(2)));
					// CalculatFrequency(a);
				}
				if(a>40000000)
				{
					a=40000000.00;
					gameInstance.SendMessage("Manager","SendToUnity","FreqMHzResult"+(a/1000).toFixed(2));
					sessionStorage.setItem("Frequency",String((a/1000).toFixed(2)));
					// CalculatFrequency(a);
				}
			}
		}
}
function SetUpWidth(arg)//设置幅度 有两种波形  //默认为0为错误频率 //为1为正确频率 范围为:
{
	var sessionStorage = window.sessionStorage;
	if(!sessionStorage){
		    console.log("该浏览器不支持本地缓存");
			sessionStorage={};
		}
		var str=arg.toString();
		str=str.replace("dBm","");
		str=str.trim();
		// alert("获取的幅度为:"+str);
		sessionStorage.setItem("SetUpWidth","true");//进行了幅度设置 
		var num=parseFloat(str).toFixed(2);
		if(num>=-145.0&&num<=25.0)
		{
			// alert("设置了幅度:"+str);
			gameInstance.SendMessage("Manager","SendToUnity","WDResult"+String(num));
			sessionStorage.setItem("Width",String(num));
		}
		else
		{
			if(num<-145.0)
			{
				str="-145.00";
				// alert("设置了幅度:"+str);
				gameInstance.SendMessage("Manager","SendToUnity","WDResult"+"-145");
				sessionStorage.setItem("Width","-145");
			}
			if(num>25.0)
			{
				str="25.00";
				// alert("设置了幅度:"+str);
				gameInstance.SendMessage("Manager","SendToUnity","WDResult"+"25");
				sessionStorage.setItem("Width","25");
			}
		}
}
function SetWireLength(arg)// 设置单极子接受天线振子长度 振子直径
{
	var sessionStorage = window.sessionStorage;
	if(!sessionStorage){
		    console.log("该浏览器不支持本地缓存");
			sessionStorage={};
		}
		var str=arg.toString().trim();
		var array=str.split(",");
		sessionStorage.setItem("zzLength",array[0]);//振子长度
		sessionStorage.setItem("ZzWireFrequency",array[1]);//频率
//		sessionStorage.setItem("zzDiameter",str);//振子直径
		//alert("单极子天线设置了振子长度"+arg.toString()+"mm");
}
function SetWireLengthWidth(arg)//设置八木天线接受天线长度  宽度 元数
{
	var sessionStorage = window.sessionStorage;
	if(!sessionStorage){
		    console.log("该浏览器不支持本地缓存");
			sessionStorage={};
		}
		var str=arg.toString().trim();
		var array=str.split(",");
		sessionStorage.setItem("Yuan",array[0]);//元数
		sessionStorage.setItem("Spacing",array[1]);//间隔
		sessionStorage.setItem("ZzWireFrequency",array[2]);//设置自制天线频率
		
//		alert("自制八木天线设置了元数:"+array[0]+"个 \n设置了间隔:"+array[1]+"mm");
}	
function StartMeasure(arg)
{
	var sessionStorage = window.sessionStorage;
	if(!sessionStorage){
		    console.log("该浏览器不支持本地缓存");
			sessionStorage={};
		}
		sessionStorage.setItem("StartMeasure","true");//开始测量状态
//		 msgbox("开始了测量");
		if(sessionStorage.getItem("ChooseEorH")=="E")
		{
			if(sessionStorage.getItem("IsEmissionWireInstalled")=="E")
				sessionStorage.setItem("1","4");
			if(sessionStorage.getItem("IsEmissionCableConnected")=="true"&&sessionStorage.getItem("IsEmissionWireInstalled")=="E")
				sessionStorage.setItem("3","2");
			if(sessionStorage.getItem("IsTestedWireInstalled")=="E")
				sessionStorage.setItem("5","4");
			if(sessionStorage.getItem("IsTestedCableConnected")=="true"&&sessionStorage.getItem("IsTestedWireInstalled")=="E")
				sessionStorage.setItem("7","2");
			if(sessionStorage.getItem("IsTurnTableCtrlCableConnected")=="true")
				{
					var num=parseInt(sessionStorage.getItem("9"));
					num=num+1;
					sessionStorage.setItem("9",String(num));
				}
			if(sessionStorage.getItem("IsTurnTablePowerConnected")=="true")
				{
					var num=parseInt(sessionStorage.getItem("10"));
					num=num+1;
					sessionStorage.setItem("10",String(num));
				}
			if(sessionStorage.getItem("IsAdjustHight")=="true")
			{
				var num=parseInt(sessionStorage.getItem("11"));
				num=num+2;
				sessionStorage.setItem("11",String(num));
			}
			if(sessionStorage.getItem("IsSignalGPIBConnected")=="true")
			{
				var num=parseInt(sessionStorage.getItem("12"));
				num=num+1;
				sessionStorage.setItem("12",String(num));
			}
			if(sessionStorage.getItem("IsSignalRFConnected")=="true")
			{
				var num=parseInt(sessionStorage.getItem("13"));
				num=num+1;
				sessionStorage.setItem("13",String(num));
			}
			if(sessionStorage.getItem("IsSpectrumGPIBConnected")=="true")
			{
				var num=parseInt(sessionStorage.getItem("14"));
				num=num+1;
				sessionStorage.setItem("14",String(num));
			}
			if(sessionStorage.getItem("IsSpectrumRFConnected")=="true")
			{
				var num=parseInt(sessionStorage.getItem("15"));
				num=num+1;
				sessionStorage.setItem("15",String(num));
			}
			if(sessionStorage.getItem("MainPower")=="true")
			{
				var num=parseInt(sessionStorage.getItem("16"));
				num=num+2;
				sessionStorage.setItem("16",String(num));
			}						
			if(sessionStorage.getItem("SignalPower")=="true")
			{
				var num=parseInt(sessionStorage.getItem("20"));
				num=num+2;
				sessionStorage.setItem("20",String(num));
			}
			if(sessionStorage.getItem("SpectrumPower")=="true")
			{
				var num=parseInt(sessionStorage.getItem("19"));
				num=num+2;
				sessionStorage.setItem("19",String(num));
			}
			if(sessionStorage.getItem("ComputerPower")=="true")
			{
				var num=parseInt(sessionStorage.getItem("17"));
				num=num+2;
				sessionStorage.setItem("17",String(num));
			}
			if(sessionStorage.getItem("MeasuringApp")=="true")
			{
				var num=parseInt(sessionStorage.getItem("18"));
				num=num+2;
				sessionStorage.setItem("18",String(num));
			}
			if(sessionStorage.getItem("SetUpFrequency")=="true")
			{
				var num=parseInt(sessionStorage.getItem("21"));
				num=num+2;
				sessionStorage.setItem("21",String(num));
			}
			if(sessionStorage.getItem("SetUpWidth")=="true")
			{
				var num=parseInt(sessionStorage.getItem("22"));
				num=num+2;
				sessionStorage.setItem("22",String(num));
			}
			if(sessionStorage.getItem("IsDarkDoorOpen")=="false")
			{
				var num=parseInt(sessionStorage.getItem("23"));
				num=num+2;
				sessionStorage.setItem("23",String(num));
			}
		}
		else{//H面实验
				if(sessionStorage.getItem("IsEmissionWireInstalled")=="H")
				sessionStorage.setItem("2","4");
			if(sessionStorage.getItem("IsEmissionCableConnected")=="true"&&sessionStorage.getItem("IsEmissionWireInstalled")=="H")
				sessionStorage.setItem("4","2");
			if(sessionStorage.getItem("IsTestedWireInstalled")=="H")
				sessionStorage.setItem("6","4");
			if(sessionStorage.getItem("IsTestedCableConnected")=="true"&&sessionStorage.getItem("IsTestedWireInstalled")=="H")
				sessionStorage.setItem("8","2");
			if(sessionStorage.getItem("IsTurnTableCtrlCableConnected")=="true")
				{
					var num=parseInt(sessionStorage.getItem("9"));
					num=num+1;
					sessionStorage.setItem("9",String(num));
				}
			if(sessionStorage.getItem("IsTurnTablePowerConnected")=="true")
				{
					var num=parseInt(sessionStorage.getItem("10"));
					num=num+1;
					sessionStorage.setItem("10",String(num));
				}
			if(sessionStorage.getItem("IsAdjustHight")=="true")
			{
				var num=parseInt(sessionStorage.getItem("11"));
				num=num+2;
				sessionStorage.setItem("11",String(num));
			}
			if(sessionStorage.getItem("IsSignalGPIBConnected")=="true")
			{
				var num=parseInt(sessionStorage.getItem("12"));
				num=num+1;
				sessionStorage.setItem("12",String(num));
			}
			if(sessionStorage.getItem("IsSignalRFConnected")=="true")
			{
				var num=parseInt(sessionStorage.getItem("13"));
				num=num+1;
				sessionStorage.setItem("13",String(num));
			}
			if(sessionStorage.getItem("IsSpectrumGPIBConnected")=="true")
			{
				var num=parseInt(sessionStorage.getItem("14"));
				num=num+1;
				sessionStorage.setItem("14",String(num));
			}
			if(sessionStorage.getItem("IsSpectrumRFConnected")=="true")
			{
				var num=parseInt(sessionStorage.getItem("15"));
				num=num+1;
				sessionStorage.setItem("15",String(num));
			}
			if(sessionStorage.getItem("MainPower")=="true")
			{
				var num=parseInt(sessionStorage.getItem("16"));
				num=num+2;
				sessionStorage.setItem("16",String(num));
			}						
			if(sessionStorage.getItem("SignalPower")=="true")
			{
				var num=parseInt(sessionStorage.getItem("20"));
				num=num+2;
				sessionStorage.setItem("20",String(num));
			}
			if(sessionStorage.getItem("SpectrumPower")=="true")
			{
				var num=parseInt(sessionStorage.getItem("19"));
				num=num+2;
				sessionStorage.setItem("19",String(num));
			}
			if(sessionStorage.getItem("ComputerPower")=="true")
			{
				var num=parseInt(sessionStorage.getItem("17"));
				num=num+2;
				sessionStorage.setItem("17",String(num));
			}
			if(sessionStorage.getItem("MeasuringApp")=="true")
			{
				var num=parseInt(sessionStorage.getItem("18"));
				num=num+2;
				sessionStorage.setItem("18",String(num));
			}
			if(sessionStorage.getItem("SetUpFrequency")=="true")
			{
				var num=parseInt(sessionStorage.getItem("21"));
				num=num+2;
				sessionStorage.setItem("21",String(num));
			}
			if(sessionStorage.getItem("SetUpWidth")=="true")
			{
				var num=parseInt(sessionStorage.getItem("22"));
				num=num+2;
				sessionStorage.setItem("22",String(num));
			}
			if(sessionStorage.getItem("IsDarkDoorOpen")=="false")
			{
				var num=parseInt(sessionStorage.getItem("23"));
				num=num+2;
				sessionStorage.setItem("23",String(num));
			}
		}
		//sessionStorage.getItem("SetUpFrequency")=="true"&&  =============================================================================
		if(sessionStorage.getItem("ChooseEorH")=="E")
		{
//			msgbox("选择了E面");
			sessionStorage.setItem("FinishE","true");
			if(sessionStorage.getItem("IsAdjustHight")=="true"&&sessionStorage.getItem("IsEmissionWireInstalled")=="E"&&sessionStorage.getItem("IsEmissionCableConnected")=="true"&&sessionStorage.getItem("SetUpFrequency")=="true"&&sessionStorage.getItem("SetUpWidth")=="true"&&sessionStorage.getItem("IsSignalGPIBConnected")=="true"&&sessionStorage.getItem("IsSignalRFConnected")=="true"&&sessionStorage.getItem("SpectrumPower")=="true"&&sessionStorage.getItem("IsSpectrumGPIBConnected")=="true"&&sessionStorage.getItem("IsTurnTableCtrlCableConnected")=="true"&&sessionStorage.getItem("IsTurnTablePowerConnected")=="true"&&sessionStorage.getItem("IsTestedCableConnected")=="true"&&sessionStorage.getItem("IsTestedWireInstalled")=="E"&&sessionStorage.getItem("IsSpectrumRFConnected")=="true"&&sessionStorage.getItem("IsSpectrumGPIBConnected")=="true")//频率设置 安装了发射天线- 调整了高度---设置了频率幅度---------------------------------------------------------------------------------
			{
//				msgbox("频率设置正确 安装了发射天线");
				if(sessionStorage.getItem("IsTestedWireInstalled")=="E"&&sessionStorage.getItem("IsTestedCableConnected")=="true")//安装了接受天线 以及电缆
				{
					gameInstance.SendMessage("Manager","SendToUnity","OpenWaveform2DE");
//					 alert("显示2DE面安装波形图");
//					 alert("天线开始转动");
					gameInstance.SendMessage("Manager","SendToUnity","WireSupportStartRotate");
					var hznum=parseFloat(String(sessionStorage.getItem("Frequency"))).toFixed(2);
					if(hznum>=800.0&&hznum<=18000.0)
					{
						gameInstance.SendMessage("Manager","SendToUnity","DrawMap");//画曲线图					
					}

				}
			}
			else{
					gameInstance.SendMessage("Manager","SendToUnity","NoWaveform2D");//无波形
			}
		}else{
			sessionStorage.setItem("FinishH","true");
			if(sessionStorage.getItem("IsAdjustHight")=="true"&&sessionStorage.getItem("IsEmissionWireInstalled")=="H"&&sessionStorage.getItem("IsEmissionCableConnected")=="true"&&sessionStorage.getItem("SetUpFrequency")=="true"&&sessionStorage.getItem("SetUpWidth")=="true"&&sessionStorage.getItem("IsSignalGPIBConnected")=="true"&&sessionStorage.getItem("IsSignalRFConnected")=="true"&&sessionStorage.getItem("SpectrumPower")=="true"&&sessionStorage.getItem("IsSpectrumGPIBConnected")=="true"&&sessionStorage.getItem("IsTurnTableCtrlCableConnected")=="true"&&sessionStorage.getItem("IsTurnTablePowerConnected")=="true"&&sessionStorage.getItem("IsTestedCableConnected")=="true"&&sessionStorage.getItem("IsTestedWireInstalled")=="H"&&sessionStorage.getItem("IsSpectrumGPIBConnected")=="true"&&sessionStorage.getItem("IsSpectrumRFConnected")=="true")//频率设置 安装了发射天线---调整了高度---设置了频率幅度-------------------------------------------------------------------------------
			{
				// alert("频率设置正确 安装了发射天线");
				if(sessionStorage.getItem("IsTestedWireInstalled")=="H"&&sessionStorage.getItem("IsTestedCableConnected")=="true")//安装了接受天线 以及电缆
				{
					gameInstance.SendMessage("Manager","SendToUnity","OpenWaveform2DH");
					// alert("显示2DH面安装波形图");
					// alert("天线开始转动");
					gameInstance.SendMessage("Manager","SendToUnity","WireSupportStartRotate");
					var hznum=parseFloat(String(sessionStorage.getItem("Frequency"))).toFixed(2);
					if(hznum>=800.0&&hznum<=18000)
					{
						gameInstance.SendMessage("Manager","SendToUnity","DrawMap");//画曲线图
					}
				}
			}
			else{
					gameInstance.SendMessage("Manager","SendToUnity","NoWaveform2D");//无波形
			}
		}
}
function StopMeasure(arg)
{
//	 alert("停止了测量");
	var score=0;
	var sessionStorage = window.sessionStorage;
	if(!sessionStorage){
			console.log("该浏览器不支持本地缓存");
			sessionStorage={};
	}
	sessionStorage.setItem("CalculatReceivedPower","false")//停止了计算接收功率
	sessionStorage.setItem("Degrees","0");//度数置为零
	gameInstance.SendMessage("Manager","SendToUnity","WireSupportStopRotate");
//	gameInstance.SendMessage("Manager","SendToUnity","StopDrawMap");//停止画曲线图
	sessionStorage.setItem("time","0");
	if(sessionStorage.getItem("StartMeasure")=="true")
	{
//		alert("已经开始了!");
		if(sessionStorage.getItem("ChooseEorH")=="E")
		{
			if(sessionStorage.getItem("FinishH")=="false")
			{
//				alert("H未完成");
				gameInstance.SendMessage("Manager","SendToUnity","ShowFinishHalfButton");
			}
			else
				gameInstance.SendMessage("Manager","SendToUnity","ShowFinishButton");
		}
		else{//H面实验
			if(sessionStorage.getItem("FinishE")=="false")
			{
//				alert("E未完成");
				gameInstance.SendMessage("Manager","SendToUnity","ShowFinishHalfButton");
			}
			else
			{
//				alert("已完成");
				gameInstance.SendMessage("Manager","SendToUnity","ShowFinishButton");
			}
		}
	 }
}

// ==============================================================================================================
function FinishEorH(arg)
{
//	alert("完成了阶段性实验");
	var sessionStorage = window.sessionStorage;
	if(!sessionStorage){
		    console.log("该浏览器不支持本地缓存");
			sessionStorage={};
		}
		if(sessionStorage.getItem("ChooseEorH")=="E")
		{
			sessionStorage.setItem("Degrees","0");//初始为零度
			gameInstance.SendMessage("Manager","SendToUnity","Htodo");
		}
		else{
			sessionStorage.setItem("Degrees","0");//初始为零度
			gameInstance.SendMessage("Manager","SendToUnity","Etodo");
		}
}
function Finish(arg)
{
	// alert("完成了总实验");
	var sessionStorage = window.sessionStorage;
	if(!sessionStorage){
		    console.log("该浏览器不支持本地缓存");
			sessionStorage={};
	}
	if(sessionStorage.getItem("SignalPower")=="false")
		sessionStorage.setItem("24","2");
	if(sessionStorage.getItem("SpectrumPower")=="false")
		sessionStorage.setItem("25","2");
	if(sessionStorage.getItem("ComputerPower")=="false")
		sessionStorage.setItem("26","2");
	if(sessionStorage.getItem("MainPower")=="false")
		sessionStorage.setItem("27","2");
	if(sessionStorage.getItem("IsSignalGPIBConnected")=="false")
		sessionStorage.setItem("28","2");
	if(sessionStorage.getItem("IsSignalRFConnected")=="false")
		sessionStorage.setItem("29","2");
	if(sessionStorage.getItem("IsSpectrumGPIBConnected")=="false")
		sessionStorage.setItem("30","2");
	if(sessionStorage.getItem("IsSpectrumRFConnected")=="false")
		sessionStorage.setItem("31","2");
	if(sessionStorage.getItem("IsEmissionCableConnected")=="false")
		sessionStorage.setItem("32","2");
	if(sessionStorage.getItem("IsEmissionWireInstalled")=="false")
		sessionStorage.setItem("33","2");
	if(sessionStorage.getItem("IsTestedCableConnected")=="false")
		sessionStorage.setItem("34","2");
	if(sessionStorage.getItem("IsTestedWireInstalled")=="false")
		sessionStorage.setItem("35","2");
	if(sessionStorage.getItem("IsTurnTableCtrlCableConnected")=="false")
		sessionStorage.setItem("36","2");
	if(sessionStorage.getItem("IsTurnTablePowerConnected")=="false")
		sessionStorage.setItem("37","2");
	if(sessionStorage.getItem("SequenceErrorCo")=="true")//操作出现错误 电脑未关关电源
		sessionStorage.setItem("26","0");
	if(sessionStorage.getItem("SequenceErrorSp")=="true")//操作出现错误 频谱仪未关关电源
		sessionStorage.setItem("25","0");
	if(sessionStorage.getItem("SequenceErrorSi")=="true")//操作出现错误 信号源未关关电源
		sessionStorage.setItem("24","0");
	if(sessionStorage.getItem("PowerErrorSi")=="true")//操作出现错误 信号源未关关电源
		sessionStorage.setItem("24","0");
	if(sessionStorage.getItem("PowerErrorSp")=="true")//操作出现错误 信号源未关关电源
		sessionStorage.setItem("25","0");
	var score=String(parseInt(sessionStorage.getItem("1"))+parseInt(sessionStorage.getItem("2"))+parseInt(sessionStorage.getItem("3"))+parseInt(sessionStorage.getItem("4"))+parseInt(sessionStorage.getItem("5"))+parseInt(sessionStorage.getItem("6"))+parseInt(sessionStorage.getItem("7"))+parseInt(sessionStorage.getItem("8"))+parseInt(sessionStorage.getItem("9"))+parseInt(sessionStorage.getItem("10"))+parseInt(sessionStorage.getItem("11"))+parseInt(sessionStorage.getItem("12"))+parseInt(sessionStorage.getItem("13"))+parseInt(sessionStorage.getItem("14"))+parseInt(sessionStorage.getItem("15"))+parseInt(sessionStorage.getItem("16"))+parseInt(sessionStorage.getItem("17"))+parseInt(sessionStorage.getItem("18"))+parseInt(sessionStorage.getItem("19"))+parseInt(sessionStorage.getItem("20"))+parseInt(sessionStorage.getItem("21"))+parseInt(sessionStorage.getItem("22"))+parseInt(sessionStorage.getItem("23"))+parseInt(sessionStorage.getItem("24"))+parseInt(sessionStorage.getItem("25"))+parseInt(sessionStorage.getItem("26"))+parseInt(sessionStorage.getItem("27"))+parseInt(sessionStorage.getItem("28"))+parseInt(sessionStorage.getItem("29"))+parseInt(sessionStorage.getItem("30"))+parseInt(sessionStorage.getItem("31"))+parseInt(sessionStorage.getItem("32"))+parseInt(sessionStorage.getItem("33"))+parseInt(sessionStorage.getItem("34"))+parseInt(sessionStorage.getItem("35"))+parseInt(sessionStorage.getItem("36"))+parseInt(sessionStorage.getItem("37")));//+parseInt(sessionStorage.getItem("38")))
	sessionStorage.setItem("38",score);
	var deductpointsString=String(4-parseInt(sessionStorage.getItem("1")))+","+String(4-parseInt(sessionStorage.getItem("2")))+","+String(2-parseInt(sessionStorage.getItem("3")))+","+String(2-parseInt(sessionStorage.getItem("4")))+","+String(4-parseInt(sessionStorage.getItem("5")))+","+String(4-parseInt(sessionStorage.getItem("6")))+","+String(2-parseInt(sessionStorage.getItem("7")))+","+String(2-parseInt(sessionStorage.getItem("8")))+","+String(2-parseInt(sessionStorage.getItem("9")))+","+String(2-parseInt(sessionStorage.getItem("10")))+","+String(4-parseInt(sessionStorage.getItem("11")))+","+String(2-parseInt(sessionStorage.getItem("12")))+","+String(2-parseInt(sessionStorage.getItem("13")))+","+String(2-parseInt(sessionStorage.getItem("14")))+","+String(2-parseInt(sessionStorage.getItem("15")))+","+String(4-parseInt(sessionStorage.getItem("16")))+","+String(4-parseInt(sessionStorage.getItem("17")))+","+String(4-parseInt(sessionStorage.getItem("18")))+","+String(4-parseInt(sessionStorage.getItem("19")))+","+String(4-parseInt(sessionStorage.getItem("20")))+","+String(4-parseInt(sessionStorage.getItem("21")))+","+String(4-parseInt(sessionStorage.getItem("22")))+","+String(4-parseInt(sessionStorage.getItem("23")))+","+String(2-parseInt(sessionStorage.getItem("24")))+","+String(2-parseInt(sessionStorage.getItem("25")))+","+String(2-parseInt(sessionStorage.getItem("26")))+","+String(2-parseInt(sessionStorage.getItem("27")))+","+String(2-parseInt(sessionStorage.getItem("28")))+","+String(2-parseInt(sessionStorage.getItem("29")))+","+String(2-parseInt(sessionStorage.getItem("30")))+","+String(2-parseInt(sessionStorage.getItem("31")))+","+String(2-parseInt(sessionStorage.getItem("32")))+","+String(2-parseInt(sessionStorage.getItem("33")))+","+String(2-parseInt(sessionStorage.getItem("34")))+","+String(2-parseInt(sessionStorage.getItem("35")))+","+String(2-parseInt(sessionStorage.getItem("36")))+","+String(2-parseInt(sessionStorage.getItem("37")))+","+String(100-parseInt(sessionStorage.getItem("38")));
	var scoresString=String(parseInt(sessionStorage.getItem("1")))+","+String(parseInt(sessionStorage.getItem("2")))+","+String(parseInt(sessionStorage.getItem("3")))+","+String(parseInt(sessionStorage.getItem("4")))+","+String(parseInt(sessionStorage.getItem("5")))+","+String(parseInt(sessionStorage.getItem("6")))+","+String(parseInt(sessionStorage.getItem("7")))+","+String(parseInt(sessionStorage.getItem("8")))+","+String(parseInt(sessionStorage.getItem("9")))+","+String(parseInt(sessionStorage.getItem("10")))+","+String(parseInt(sessionStorage.getItem("11")))+","+String(parseInt(sessionStorage.getItem("12")))+","+String(parseInt(sessionStorage.getItem("13")))+","+String(parseInt(sessionStorage.getItem("14")))+","+String(parseInt(sessionStorage.getItem("15")))+","+String(parseInt(sessionStorage.getItem("16")))+","+String(parseInt(sessionStorage.getItem("17")))+","+String(parseInt(sessionStorage.getItem("18")))+","+String(parseInt(sessionStorage.getItem("19")))+","+String(parseInt(sessionStorage.getItem("20")))+","+String(parseInt(sessionStorage.getItem("21")))+","+String(parseInt(sessionStorage.getItem("22")))+","+String(parseInt(sessionStorage.getItem("23")))+","+String(parseInt(sessionStorage.getItem("24")))+","+String(parseInt(sessionStorage.getItem("25")))+","+String(parseInt(sessionStorage.getItem("26")))+","+String(parseInt(sessionStorage.getItem("27")))+","+String(parseInt(sessionStorage.getItem("28")))+","+String(parseInt(sessionStorage.getItem("29")))+","+String(parseInt(sessionStorage.getItem("30")))+","+String(parseInt(sessionStorage.getItem("31")))+","+String(parseInt(sessionStorage.getItem("32")))+","+String(parseInt(sessionStorage.getItem("33")))+","+String(parseInt(sessionStorage.getItem("34")))+","+String(parseInt(sessionStorage.getItem("35")))+","+String(parseInt(sessionStorage.getItem("36")))+","+String(parseInt(sessionStorage.getItem("37")))+","+String(parseInt(sessionStorage.getItem("38")));//+","+String(parseInt(sessionStorage.getItem("39")))
	var loginer=localStorage.getItem("loginer");
    var json=JSON.parse(loginer);
    var sid=json.username;//获取得到当前登录用户名
	var data={sid:sid,deductpointsString:deductpointsString,scoresString:scoresString};//传入数据
	ajax("/stepitemrecord/addstepitemrecord", data, function(d) {
				var msg=d.msg;
				msgbox(msg);
			window.location.href="stu_achievement.html";//转入成绩界面
		 },"post","application/x-www-form-urlencoded")
}
function OnClickBack(arg)
{
	init();
	// alert("进行初始化");
}
// =============================================数学函数======================================
function CalculatFrequency(arg)
{
//		 alert("调用了CalculatFrequency");
		var sessionStorage = window.sessionStorage;
		if(!sessionStorage){
		    console.log("该浏览器不支持本地缓存");
			sessionStorage={};
		}
	    var txt="CalculatFrequency"+","+arg.toString();
		var data={txt:txt};
		//alert("HZ:"+txt);
        ajax("/formula/formula", data, function(d) {    
        	 var str = JSON.stringify(d.data[0]);
        	 var result=str.replace(/\"/g, "");
             var resultb=parseFloat(result).toFixed(2);
				 //alert("CalculatFrequency:"+String(resultb));
				if(sessionStorage.getItem("IsEmissionCableConnected")=="true")
				{
					if(sessionStorage.getItem("IsEmissionWireInstalled")=="E"&&sessionStorage.getItem("IsSignalGPIBConnected")=="true"&&sessionStorage.getItem("IsSignalRFConnected")=="true")
					{
							gameInstance.SendMessage("Manager","SendToUnity","FQResult"+String(resultb));//发送计算的频率值 //MHz
							gameInstance.SendMessage("Manager","SendToUnity","OpenWaveformE");
							// alert("暗室显示波形E");
					}
					if(sessionStorage.getItem("IsEmissionWireInstalled")=="H"&&sessionStorage.getItem("IsSignalGPIBConnected")=="true"&&sessionStorage.getItem("IsSignalRFConnected")=="true")
					{
							gameInstance.SendMessage("Manager","SendToUnity","FQResult"+String(resultb));//发送计算的频率值 //MHz
							gameInstance.SendMessage("Manager","SendToUnity","OpenWaveformH");
							// alert("暗室显示波形H");
					}
				}
			 },"post","application/x-www-form-urlencoded")
}
function CalculatReceivedPower(arg){//arg格式为:xxGMKHz,xxdBm
//	 alert("调用了CalculatReceivedPower");
	var sessionStorage = window.sessionStorage;
	if(!sessionStorage){
		    console.log("该浏览器不支持本地缓存");
			sessionStorage={};
		}
//		 alert("调用接受功率计算函数");
		if((sessionStorage.getItem("IsEmissionWireInstalled")=="E"&&sessionStorage.getItem("IsTestedWireInstalled")=="E")||(sessionStorage.getItem("IsEmissionWireInstalled")=="H"&&sessionStorage.getItem("IsTestedWireInstalled")=="H"))//判断极化方式是否相同
		{
			var Polarization="agreement";
		}
		else{
			var Polarization="notagreement";
		}
		var Degrees=parseInt(sessionStorage.getItem("Degrees"));
		// alert(Degrees);
		var hznum=parseFloat(String(sessionStorage.getItem("Frequency"))).toFixed(2);//MHz
		// alert(hznum);
		var dbmnum=parseFloat(String(sessionStorage.getItem("Width"))).toFixed(2);//获取幅度值 dBm
		// alert(dbmnum);
		var IsTestedWireInstalled=sessionStorage.getItem("IsTestedWireInstalled").toString();//接受天线安装方式
		var TestedWireInstalledName=sessionStorage.getItem("TestedWireInstalledName");//获取接受天线名称 
		// var TestedWireInstalledName="Yagiantenna";//获取接受天线名称 上面为最终形式
//		 alert(TestedWireInstalledName);
		if(hznum>=800.0&&hznum<=18000.0&&((hznum>=2300.0&&hznum<=2500.0&&TestedWireInstalledName=="Whipantenna")||(hznum>=800.0&&hznum<=960.0&&TestedWireInstalledName=="Yagiantenna")||(hznum>=8200.0&&hznum<=12400.0&&TestedWireInstalledName=="Hornantenna")||(hznum>=5725.0&&hznum<=5850.0&&TestedWireInstalledName=="Parabolicantenna")||(sessionStorage.getItem("ZzWireFrequency")=="800"&&hznum==800.0&&TestedWireInstalledName=="Monopoleantenna")||(sessionStorage.getItem("ZzWireFrequency")=="800"&&hznum==800.0&&TestedWireInstalledName=="HomemadeYagiantenna")))
		{
			sessionStorage.setItem("CalculatReceivedPower","true");//计算了接受功率
//			 alert("输入的频率符合要求");
			if(TestedWireInstalledName=="Monopoleantenna"||TestedWireInstalledName=="HomemadeYagiantenna")
			{
				if(TestedWireInstalledName=="Monopoleantenna")//单极子天线
				{
					var zzLength=sessionStorage.getItem("zzLength");//获取振子长度
					if(Degrees==0)
					{
						var txt="CalculatReceivedPower"+","+String(hznum)+","+String(dbmnum)+","+String(Degrees)+","+Polarization+","+IsTestedWireInstalled+","+TestedWireInstalledName+","+zzLength;
					}	
					else
						{
							var initresult=sessionStorage.getItem("initResult");
							var txt="CalculatReceivedPower"+","+String(hznum)+","+String(dbmnum)+","+String(Degrees)+","+Polarization+","+IsTestedWireInstalled+","+TestedWireInstalledName+","+zzLength+","+initresult;
						}
//					alert(txt);
				}
				if(TestedWireInstalledName=="HomemadeYagiantenna")//八木天线
				{
					var Yuan=sessionStorage.getItem("Yuan");
					var Spacing=sessionStorage.getItem("Spacing");
					if(Degrees==0)
					{
						var txt="CalculatReceivedPower"+","+String(hznum)+","+String(dbmnum)+","+String(Degrees)+","+Polarization+","+IsTestedWireInstalled+","+TestedWireInstalledName+","+Yuan+","+Spacing;
					}	
					else
						{
							var initresult=sessionStorage.getItem("initResult");
							var txt="CalculatReceivedPower"+","+String(hznum)+","+String(dbmnum)+","+String(Degrees)+","+Polarization+","+IsTestedWireInstalled+","+TestedWireInstalledName+","+Yuan+","+Spacing+","+initresult;
						}
					
//					alert(txt);
				}
			}
			else
			{
				if(Degrees==0)
				{
					var txt="CalculatReceivedPower"+","+String(hznum)+","+String(dbmnum)+","+String(Degrees)+","+Polarization+","+IsTestedWireInstalled+","+TestedWireInstalledName;
				}	
				else
					{
						var initresult=sessionStorage.getItem("initResult");
						var txt="CalculatReceivedPower"+","+String(hznum)+","+String(dbmnum)+","+String(Degrees)+","+Polarization+","+IsTestedWireInstalled+","+TestedWireInstalledName+","+initresult;
					}
//				alert(txt);
			}
			var data= {txt:txt};
			ajax("/formula/formula", data, function(d) {    
				 	var string = JSON.stringify(d.data[0]);
				 	var str=string.replace(/\"/g, "");
		            if(str=="fail")
		            {
		            	msgbox("遇到未知错误!");
		            	return;
		            }
					var array=str.split(",");
					var result=parseFloat(array[0].trim()).toFixed(2);
//					alert(result);//当前接受的功率值
					if(Degrees==0)
					{
						sessionStorage.setItem("initResult",String(result));
//						alert("存入initResult为:"+sessionStorage.getItem("initResult"));
						sessionStorage.setItem("Pointx",array[1]);
						sessionStorage.setItem("Pointy",array[2]);
						// 发送x y坐标
						gameInstance.SendMessage("Manager","SendToUnity","Pointz"+array[1]);
						gameInstance.SendMessage("Manager","SendToUnity","Pointy"+array[2]);
					}
					else{
						var px=parseFloat(sessionStorage.getItem("Pointx"));
						var py=parseFloat(sessionStorage.getItem("Pointy"));
						var fdatx=(parseFloat(array[1])-px)/100;
						var fdaty=(parseFloat(array[2])-py)/100;
						var num=1;
						while (num<=100){//100次循环将两点分为100个点
							var x=num*fdatx+px;
							var y=num*fdaty+py;
							// 发送x y坐标
							if(Degrees==0)
								alert(x+","+y);
							gameInstance.SendMessage("Manager","SendToUnity","Pointz"+String(x.toFixed(2)));
							gameInstance.SendMessage("Manager","SendToUnity","Pointy"+String(y.toFixed(2)));
							num++;
						}
						sessionStorage.setItem("Pointx",array[1]);
						sessionStorage.setItem("Pointy",array[2]);
					}
//					alert("当前度数:"+String(Degrees));
//					alert("当前度数取余于10:"+String(Degrees%10));
//					alert("当前坐标("+array[1]+","+array[2]+")");
//					if(Degrees%10==0)
//					{
//						alert("当前发送的接收频率:"+String(result));
						gameInstance.SendMessage("Manager","SendToUnity","RPResult"+String(result));//控制右侧表格显示
//					}
					if(Degrees==359)//循环度数
					{
						Degrees=0;
					}
					else{
						Degrees=Degrees+1;
					}
					sessionStorage.setItem("Degrees",String(Degrees));   
   			 },"post","application/x-www-form-urlencoded")
		
		}
}
function ClickTVScreen(arg)
{
	var sessionStorage = window.sessionStorage;
	if(!sessionStorage){
		    console.log("该浏览器不支持本地缓存");
			sessionStorage={};
		}
	if(sessionStorage.getItem("MainPower")=="true")//电源为开启状态 
	{
//		alert("打开TV 发送TVOpen");
		gameInstance.SendMessage("Manager","SendToUnity","TVOpen");
	}
	else
		{
			gameInstance.SendMessage("Manager","SendToUnity","TVClose");
//			alert("关闭TV 发送TVClose");
		}
}
function ClickComputerScreen(arg)
{
	var sessionStorage = window.sessionStorage;
	if(!sessionStorage){
		    console.log("该浏览器不支持本地缓存");
			sessionStorage={};
		}
	if(sessionStorage.getItem("ComputerPower")=="true")//电源为开启状态 
	{
//		alert("打开电脑 发送ComputerOpen");
		gameInstance.SendMessage("Manager","SendToUnity","ComputerOpen");
	}
	else
		{
			gameInstance.SendMessage("Manager","SendToUnity","ComputerClose");
//			alert("关闭电脑 发送ComputerClose");
		}
}
function OpenSpectrumScreen(arg)//打开频谱仪
{
	var sessionStorage = window.sessionStorage;
	if(!sessionStorage){
		    console.log("该浏览器不支持本地缓存");
			sessionStorage={};
		}
	var hznum=parseFloat(String(sessionStorage.getItem("Frequency"))).toFixed(2);
	if(sessionStorage.getItem("IsSpectrumGPIBConnected")=="true"&&sessionStorage.getItem("IsSpectrumRFConnected")=="true"&&(hznum>=800.0&&hznum<=18000.0)&&sessionStorage.getItem("CalculatReceivedPower")=="true"&&sessionStorage.getItem("SpectrumPower")=="true")
	{
		gameInstance.SendMessage("Manager","SendToUnity","startAUTOTUNE");
		gameInstance.SendMessage("Manager","SendToUnity","StopNoiseLevel");
	}
	else{
			gameInstance.SendMessage("Manager","SendToUnity","ShowNoiseLevel");
	}
	
}
function ClearSignalData(arg)//信号源开关 初始为关闭
{
	var sessionStorage = window.sessionStorage;
	if(!sessionStorage){
		    console.log("该浏览器不支持本地缓存");
			sessionStorage={};
		}
		gameInstance.SendMessage("Manager","SendToUnity","WireSupportStopRotate");
		gameInstance.SendMessage("Manager","SendToUnity","NoWaveform");
		sessionStorage.setItem("Frequency","0");//MHz
		sessionStorage.setItem("Width","0");//dBm
		sessionStorage.setItem("SetUpFrequency","false");
		sessionStorage.setItem("SetUpWidth","false");
		return;	
}
//function JudgeSPeConnected(arg)//判断频谱仪线是否连接以及频率是否设置正确
//{
//	var sessionStorage = window.sessionStorage;
//	if(!sessionStorage){
//		    console.log("该浏览器不支持本地缓存");
//			sessionStorage={};
//		}
//	var hznum=parseFloat(String(sessionStorage.getItem("Frequency"))).toFixed(2);
//	if(sessionStorage.getItem("IsSpectrumGPIBConnected")=="true"&&sessionStorage.getItem("IsSpectrumRFConnected")=="true"&&(hznum>=800.0&&hznum<=18000.0)&&sessionStorage.getItem("CalculatReceivedPower")=="true"&&sessionStorage.getItem("SpectrumPower")=="true")
//	{
//		gameInstance.SendMessage("Manager","SendToUnity","SpeTure");
//	}
//	else
//	{
//		gameInstance.SendMessage("Manager","SendToUnity","SpeFalse");
//	}
//}