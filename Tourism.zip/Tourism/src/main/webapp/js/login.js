$(function() {

  var popup = {
    login: function() {
      $(".login").show();
      $(".register").hide();
    },
    register: function() {
      $(".login").hide();
      $(".register").show();
    },
    autoCenter: function() {//居中
        var _top = ($(".container").height() - $(".con-right").innerHeight()) / 2;
        $(".con-right").css({
          'margin-top': _top
        });
      }
    }; 
    //垂直居中
    popup.autoCenter();


    //兼容IE低版本的提醒文字
    $('.con-right input').focus(function() {
      $(this).parent().find('p').hide();
    });
    $('.con-right input').blur(function() {
      if ($(this).val() == '') {
        $(this).parent().find('p').show();
      }
    });

    //点击文字，让登录框的输入框获取焦点
    $(".con-right p").click(function(){
      $(this).parent().find('input').focus();
    });
    
    

  })
$(document).ready(function(){			
			$("#submit").click(function(){
				var gsid=$("#sid").val();//获取当前文本框中的值	
				if(gsid==""){
					msgbox("请输入学号!");
					return;
					}
				var psd=$("#password").val();
				if(psd==""){
					msgbox("请输入密码!");
					return;
					}
        var password = $.md5(gsid+psd);
				var gdty=$("input[name='getidentity']:checked").val();
				var  data= {username:gsid,password:password};
                //通过ajax传值        
                 ajax("/login", data, function(d) {   
            		var loginer = JSON.stringify(d.data[0]);
            		var json=JSON.parse(loginer);
            		localStorage.setItem("loginer", loginer); 
                 	if(json.identity=="notAdmin")
                	{
                 		if(gdty=="student")
                 			  window.location.href="stu_info.html";
                 		else
                 			msgbox("请选择正确身份!");
                	}
                 	if(json.identity=="isAdmin")
                 	{
                 		if(gdty=="teacher")
                 		  window.location.href="tea_cherinfo.html";
                 		else
                 			msgbox("请选择正确身份!");
                 	}        
       			 },"post","application/x-www-form-urlencoded")
            });	
		});


	