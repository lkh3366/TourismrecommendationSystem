
var loginer = JSON.parse(localStorage.getItem("loginer"));
var base = "";
//============================通用函数==================================================
//字符串的getBytes方法
String.prototype.getBytes = function() {
    var cArr = this.match(/[^\x00-\xff]/ig);       
    return this.length + (cArr == null ? 0 : cArr.length); //汉字则返回2个字节 其他返回1个字节，结果为各种情况相加
}    
//将时间戳转换为日期字符串
function getDate(stamp) {
    var now = new Date(stamp),
    y = now.getFullYear(),
    m = now.getMonth() + 1,
    d = now.getDate();
    return y + "-" + (m < 10 ? "0" + m : m) + "-" + (d < 10 ? "0" + d : d) + " " + now.toTimeString().substr(0, 8);
}
//根据消息长度调整消息框自动关闭时间
function msgbox(msg) {
    if(typeof(msg)!="undefined") {
        layer.msg(msg,{time: msg.getBytes()*70});
    }    
}

function ajax(url,data,fn,type,contentType) {
    if(typeof(type)=="undefined") {type="get"}
    if(typeof(contentType)=="undefined") {
        contentType = ((type=="post") ? "application/json" : "application/x-www-form-urlencoded");
    }
    $.ajax({
        url: base+url
        ,data: data
        ,type: type
        ,dataType: "json"
        ,contentType: contentType
        ,success: function(result) {
            if((result.code==200) && (typeof(fn)!='undefined')) {
                fn(result);
            } else {
                var msg = result.msg;
                msgbox(msg);
            }
        }        
        ,error: function(result) {
            msgbox("请求错误，错误代码："+result.status);
        }
    })
}

//发送自动心跳
setInterval(() => {
    $.get(base+"/heartbeat");
}, 120000);

//ZTree组件的通用配置，单击自动展开节点
var globeTreeOption = {
    data:{//表示tree的数据格式
        key: {
            name: "title"
        },
        simpleData:{
            enable: true,//表示使用简单数据模式
            idKey: "id",//设置之后id为在简单数据模式中的父子节点关联的桥梁
            pIdKey: "parentid",//设置之后pid为在简单数据模式中的父子节点关联的桥梁和id互相对应
            rootId: 0//pid为null的表示根节点
        }
    }
    ,view:{//表示tree的显示状态
        selectMulti:false//表示禁止多选
        ,dblClickExpand: false//禁止双击展开节点
    }
    // check:{//表示tree的节点在点击时的相关设置
    //     enable:true,//是否显示radio/checkbox
    //     chkStyle:"checkbox",//值为checkbox或者radio表示
    //     checkboxType:{p:"",s:""},//表示父子节点的联动效果
    //     radioType:"level"//设置tree的分组
    // },
    ,callback:{//表示tree的一些事件处理函数
        onClick: treeNodeClickExpand//实现单击展开节点
    }
}
function treeNodeClickExpand(event, treeId, treeNode) {	
    let ttree = $.fn.zTree.getZTreeObj(treeId);
    ttree.selectNode(treeNode);//在树中选中用户点击的节点
    ttree.expandNode(treeNode,true);//展开节点
}

//LayUI数据表格组件的通用配置
var globeTablePage = { //支持传入 laypage 组件的所有参数（某些参数除外，如：jump/elem） - 详见文档
    layout: ['prev', 'page', 'next', 'skip', 'limit', 'count'] //自定义分页布局
    ,curr: 1 //设定初始在第 1 页
    ,groups: 3 //连续出现的页码个数,默认3
//     ,limit: 5 //每页显示的条数（默认：10）
    ,limits: [5,10,20,50] //每页条数的选择项，默认：[10,20,30,40,50,60,70,80,90]
    ,first: "首页" //false不显示首页
    ,last: "末页" //false不显示尾页
    ,theme: 'tb-page'                
}
var globeTableResponse = {
    statusCode: 200 //规定成功的状态码，默认：0
    // ,statusName: 'status' //规定数据状态的字段名称，默认：code
    // ,msgName: 'hint' //规定状态信息的字段名称，默认：msg
    // ,countName: 'total' //规定数据总数的字段名称，默认：count
    // ,dataName: 'rows' //规定数据列表的字段名称，默认：data
}